import { getStore } from "@netlify/blobs";
import { handle } from "../lib/radio.mjs";

export default async (req) => handle(req, getStore({ name: "radio", consistency: "strong" }));

export const config = { path: "/api/*" };
